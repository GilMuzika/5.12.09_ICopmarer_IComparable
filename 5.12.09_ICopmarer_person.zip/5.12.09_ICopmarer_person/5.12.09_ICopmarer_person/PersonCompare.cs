﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5._12._09_ICopmarer_person
{
    abstract class PersonCompare
    {
        abstract public bool IsIcomparer { get; }
    }
}
